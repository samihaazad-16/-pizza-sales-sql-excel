"""Load the sample CSVs into SQLite and export the results used in Excel."""

import csv
import sqlite3
from contextlib import closing
from pathlib import Path

PROJECT = Path(__file__).resolve().parent

TABLES = {
    "products": ("product_id", "product_name", "category"),
    "orders": ("order_id", "order_date", "channel"),
    "order_lines": (
        "order_id", "line_number", "product_id", "quantity", "unit_price_cents"
    ),
}

EXPORTS = {
    "monthly_sales": "month",
    "category_sales": "revenue_usd DESC, category",
    "product_sales": "revenue_rank, product_id",
    "channel_sales": "revenue_usd DESC, channel",
    "sales_detail": "order_date, order_id, line_number",
}


def main():
    output = PROJECT / "results"
    output.mkdir(exist_ok=True)
    database = output / "sales.sqlite"
    pending_database = output / "sales-build.sqlite"

    with closing(sqlite3.connect(pending_database)) as connection:
        connection.executescript(
            "DROP VIEW IF EXISTS channel_sales;"
            "DROP VIEW IF EXISTS product_sales;"
            "DROP VIEW IF EXISTS category_sales;"
            "DROP VIEW IF EXISTS monthly_sales;"
            "DROP VIEW IF EXISTS sales_detail;"
            "DROP TABLE IF EXISTS order_lines;"
            "DROP TABLE IF EXISTS orders;"
            "DROP TABLE IF EXISTS products;"
        )
        connection.executescript((PROJECT / "schema.sql").read_text(encoding="utf-8"))

        with connection:
            for table, columns in TABLES.items():
                with (PROJECT / "data" / f"{table}.csv").open(
                    newline="", encoding="utf-8"
                ) as source:
                    rows = csv.DictReader(source)
                    if tuple(rows.fieldnames or []) != columns:
                        raise ValueError(f"Unexpected CSV columns for {table}")
                    placeholders = ", ".join("?" for _ in columns)
                    connection.executemany(
                        f"INSERT INTO {table} VALUES ({placeholders})",
                        (tuple(row[column] for column in columns) for row in rows),
                    )

        connection.executescript((PROJECT / "analysis.sql").read_text(encoding="utf-8"))
        line_count, joined_count, order_count, joined_orders = connection.execute(
            """
            SELECT (SELECT COUNT(*) FROM order_lines),
                   (SELECT COUNT(*) FROM sales_detail),
                   (SELECT COUNT(*) FROM orders),
                   (SELECT COUNT(DISTINCT order_id) FROM sales_detail)
            """
        ).fetchone()
        if line_count != joined_count or order_count != joined_orders:
            raise ValueError("Order or order-line counts failed to reconcile")

        for view, ordering in EXPORTS.items():
            result = connection.execute(f"SELECT * FROM {view} ORDER BY {ordering}")
            with (output / f"{view}.csv").open("w", newline="", encoding="utf-8") as file:
                writer = csv.writer(file)
                writer.writerow(column[0] for column in result.description)
                writer.writerows(result)

    pending_database.replace(database)
    print(f"Analyzed {order_count:,} orders and {line_count:,} order lines.")
    print("SQLite database and result CSVs are in the results folder.")


if __name__ == "__main__":
    main()
