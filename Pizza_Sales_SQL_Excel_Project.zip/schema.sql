PRAGMA foreign_keys = ON;

CREATE TABLE products (
    product_id TEXT PRIMARY KEY NOT NULL,
    product_name TEXT NOT NULL UNIQUE,
    category TEXT NOT NULL
);

CREATE TABLE orders (
    order_id TEXT PRIMARY KEY NOT NULL,
    order_date TEXT NOT NULL,
    channel TEXT NOT NULL CHECK (channel IN ('Delivery', 'Pickup', 'Walk-in'))
);

CREATE TABLE order_lines (
    order_id TEXT NOT NULL REFERENCES orders (order_id),
    line_number INTEGER NOT NULL CHECK (line_number > 0),
    product_id TEXT NOT NULL REFERENCES products (product_id),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price_cents INTEGER NOT NULL CHECK (unit_price_cents > 0),
    PRIMARY KEY (order_id, line_number)
);
